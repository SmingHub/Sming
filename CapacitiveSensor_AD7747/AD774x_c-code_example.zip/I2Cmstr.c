/********************************************************************
 Author     : Analog Devices Inc.
              Instrumentation Converters (ICV) Applications (M.B.)

 Date       : August 2004

 File       : I2Cmstr.c

 Hardware   : ADuC814

 Description: I2C master software implementation

 Reference  : Tech Note uC001 - "MicroConverter I2C Compatible
              Interface" find it at www.analog.com/microconverter

 Status     : In debug
********************************************************************/

#include <ADuC814.h>      // 8052 & ADuC824 predefined symbols

//*******************************************************************

void I2C_master_init(void)
{
  CFG814 |= 0x01;         // set serial interface enable bit
  I2CCON = 0xA8;          // master mode, initial state for SDA & SCL
} // end of I2C_init

//*******************************************************************

void I2C_Start(void)
{
  MDE = 1;        // SDA output
  MDO = 1;        // SDA hi
  MCO = 1;        // SCL hi
  MDO = 0;        // SDA lo
  MCO = 0;        // SCL lo
} // end of I2C_Start

//*******************************************************************

void I2C_Stop(void)
{
  MDE = 1;        // SDA output
  MDO = 0;        // SDA lo
  MCO = 1;        // SCL hi
  MDO = 1;        // SDA hi
} // end of I2C_Stop

//*******************************************************************

bit I2C_Snd_Byte(unsigned char d)
// Sends one byte to I2C
//
// Returns 0 if byte is acknowledged by slave
// Returns 1 if transaction fails
{
  unsigned char i;
  unsigned char noack;

  MDE = 1;        // SDA output
  for (i=8; i>0; i--)
  {
    // consider _crol_(d,1) ?
    MDO = d >> 7; // send data -> SDA
    MCO = 1;      // SCL hi
    MCO = 0;      // SCL lo
    d <<= 1;      // rotate data
  }
  MDE = 0;        // SDA input
  MCO = 1;        // SCL hi
  noack = MDI;      // check SDA for ACK 
  MCO = 0;        // SCL lo
//  return(noack);

  return(0); // *************************** FOR DEBUG - NO ACK CHECK !

} // end of I2C_Snd_Byte

//*******************************************************************

unsigned char I2C_Rcv_Byte(bit noack)
// Receives one byte from I2C
//
// noack should be 0 if other bytes will be received
// i.e., slave will be sent ACK
//
// noack should be 1 if this is the last byte
// i.e., slave will be sent NACK
{
  unsigned char i;
  unsigned char d;

  MDE = 0;        // SDA input
  for (i=8; i>0; i--)
  {
    MCO = 1;      // SCL hi
    // consider using _crol_(d,1) ?
    d <<= 1;      // rotate data
    d |= MDI;     // read SDA -> data
    MCO = 0;      // SCL lo
  }
  MDE = 1;        // SDA output
  MDO = noack;    // SDA = ACK .. NACK for the last byte
  MCO = 1;        // SCL hi
  MCO = 0;        // SCL lo
  MDE = 0;        // SDA input - release
  return(d);

} // end of I2C_Rcv_Byte

//*******************************************************************

unsigned char I2C_Snd(unsigned char Type, unsigned char Adr, unsigned int Ptr, 
                      unsigned char Length, unsigned char* Buffer)
{
  unsigned char i;

  I2C_Start();                  // Start I2C transaction

  if (I2C_Snd_Byte(Adr & 0xFE)) // Send slave address, write
  {
    // if NACK, terminate transaction
    I2C_Stop();
    return(1);
  }

  if (Type > 1)                 // Check if 16-bit pointer is used
  {
    if (I2C_Snd_Byte(Ptr >> 8)) // Send high byte of pointer
    {
      // if NACK, terminate transaction
      I2C_Stop();
      return(1);
    }
  }

  if (Type > 0)                 // Check if pointer is used
  {
    if (I2C_Snd_Byte(Ptr & 0x00FF)) // Send pointer (low byte)
    {
      // if NACK, terminate transaction
      I2C_Stop();
      return(1);
    }
  }
    
  for (i=0; i<Length; i++)
  {
    if (I2C_Snd_Byte(*(Buffer+i)))    // Send data
    {
      // if NACK, terminate transaction
      I2C_Stop();
      return(1);
    }
  }

  I2C_Stop();                   // Stop I2C transaction
  return(0);                    // Confirm no error

} // end of I2C_Snd

//*******************************************************************

unsigned char I2C_Rcv(unsigned char Type, unsigned char Adr, unsigned int Ptr, 
                      unsigned char Length, unsigned char* Buffer)
{
  unsigned char i;

  if (!Length) return(1);       // Length MUST be > 0 !!!

  // ----------------------------------------------------------------
  // This code is executed only if the I2C pointer is used
  // ----------------------------------------------------------------

  if (Type > 0)                 // Check if pointer is used
  {
    I2C_Start();                  // Start I2C transaction

    if (I2C_Snd_Byte(Adr & 0xFE)) // Send slave address, write
    {
      // if NACK, terminate transaction
      I2C_Stop();
      return(1);
    }

    if (Type > 1)                 // Check if 16-bit pointer is used
    {
      if (I2C_Snd_Byte(Ptr >> 8)) // Send high byte of pointer
      {
        // if NACK, terminate transaction
        I2C_Stop();
        return(1);
      }
    }

    if (I2C_Snd_Byte(Ptr & 0xFF)) // Send pointer (low byte)
    {
      // if NACK, terminate transaction
      I2C_Stop();
      return(1);
    }
  }
    
  // ----------------------------------------------------------------
  // From here the code is executed regardless on the I2C pointer
  // ----------------------------------------------------------------

  I2C_Start();                  // Start I2C transaction

  if (I2C_Snd_Byte(Adr | 0x01)) // Send slave address, read
  {
    // if NACK, terminate transaction
    I2C_Stop();
    return(1);
  }

  // Cycle through data except the last byte
  Length--;
  for (i=0; i<Length; i++)
  {
    *(Buffer+i) = I2C_Rcv_Byte(0);  // Receive data and do ACK
  }

  // The last byte
  *(Buffer+i) = I2C_Rcv_Byte(1);  // Receive data and do NOT ACK

  I2C_Stop();                   // Stop I2C transaction
  return(0);                    // Confirm no error

} // end of I2C_Rcv

//*******************************************************************

