/********************************************************************
 Author     : Analog Devices Inc.
              Instrumentation & Automotive Converters (IAC) 
              Applications (M.B.)

 Date       : March 2005

 File       : AD774x_basic.c

 Hardware   : AD774x interfaced to ADuC814

 Description: Repeats single conversions on Cin1 and Cin2
              Sends results to UART, 9600-8-n-1, ASCII HEX format
              Code is not optimized for speed, but for simplicity

 Status     : Checked 
********************************************************************/

#include <I2Cmstr.c>      // I2C interface implemented for ADuC814
#include <stdio.h>        // Standard I/O functions

/********************************************************************
 MAIN PROGRAM
********************************************************************/

void main (void) 
{
  unsigned char Setup[4];
  unsigned char Data[3];

/********************************************************************
 INITIALIZATION
********************************************************************/
                        
  // CONFIGURE UART
  SCON = 0x52;          // 8bit, No Parity, 1 Stop Bit
  T2CON = 0x34;         // Configure Timer 2 as baud rate generator
  RCAP2H = TH2 = 0xFF;  // 9600bd @ Fcore=2MHz (-2.5%)
  RCAP2L = TL2 = 0xF9;  // 

  // CONFIGURE I2C
  I2C_master_init();    // refer to I2Cmstr.c 
   
  // SEND HEADER TO UART
  printf("\nAD774x code example\nSource file 'AD774x_basic.c'\n");
  printf("\nCH1\tCH2\n");
  
/********************************************************************
 DATA AQUISITION LOOP
********************************************************************/
 // The loop performes a single convertion and reads out the convertion results 
  while(1) {            // Endless loop

    // START CONVERSION ON AD774x
    // ==============================
    Setup[0] = 0xA0;  // (Cap Setup Reg) Enable Cap Channel , CAPDIFF on
    Setup[1] = 0x81;  // (VT Setup Reg) Enable Voltage/Temperature, Chop on
    Setup[2] = 0x0E;  // (EXC Setup Reg) Enable Exc, Level = Vdd*3/8
    Setup[3] = 0xA2;  // (Configuration Reg) Start single conversion, Default rate
    I2C_Snd(1, 0x90, 0x07, 4, Setup); // Send setup to AD7747
    // Send to I2C: 
    // 1    .. Transaction with 1-byte address pointer
    // 0x90 .. AD774x device address
    // 0x07 .. starting adress pointer - AD774x Cap Setup register
    // 4    .. 4 bytes to be sent
    // Setup .. array of bytes to be sent

    // WAIT FOR AD774x RDY
    do {
      I2C_Rcv(1, 0x90, 0x00, 1, Data);  // Read AD774x Status
    } while (Data[0] & 0x04);           // Wait for RDY bit = 0

    // READ AD774x DATA CAP CHANNEL
    I2C_Rcv(1, 0x90, 0x01, 3, Data);    // Read AD774x Data

    // SEND DATA TO UART
    // ==============================
    printf("%02bX%02bX%02bX\t",Data[0],Data[1],Data[2]);
 
    // READ AD774x DATA VT CHANNEL
    I2C_Rcv(1, 0x90, 0x04, 3, Data);    // Read AD774x Data

    // SEND DATA TO UART
    // ==============================
    printf("%02bX%02bX%02bX\t",Data[0],Data[1],Data[2]);

   // to convert the code to degC you have to calculate the following formula
   // degC = decimal(Data) / 2048 - 4096

  }  // while
} // main


